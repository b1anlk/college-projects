class DoctorIndividual 
{

}
